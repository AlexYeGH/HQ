It's HTML code
<br>
<?php echo $a; ?>