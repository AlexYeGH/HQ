<?php

include_once("ClassLoader.php");

ClassLoader::getInstance();

Application::getInstance()->init();